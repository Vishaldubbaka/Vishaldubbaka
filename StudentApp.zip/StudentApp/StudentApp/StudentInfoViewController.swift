//
//  StudentInfoViewController.swift
//  StudentApp
//
//  Created by Dubbaka,Vishal Reddy on 3/24/22.
//

import UIKit

class StudentInfoViewController: UIViewController {
    
    
    @IBOutlet weak var SIdOutlet: UILabel!
    
    @IBOutlet weak var EmailOutlet: UILabel!
    
    @IBOutlet weak var NameOutlet: UILabel!
    
    
    @IBOutlet weak var ViewCoursesButton: UIButton!
    
    var studentObj = Student()
    
    var guestUser:Bool = false
    override func viewDidLoad() {
        super.viewDidLoad()
       
        if guestUser {
            //if the user is guest we will hide all the outlets and display 'Guest User'
            EmailOutlet.isHidden = true
            NameOutlet.text = "Name: Guest User"
            SIdOutlet.isHidden = true
            ViewCoursesButton.isHidden = true
            
        }else{
            
            //If the student is found, then we assign the values of the studentObj to the outelts
            SIdOutlet.text = "SID: " + studentObj.sid
            EmailOutlet.text = "Email: " + studentObj.email
            NameOutlet.text = "Name: " + studentObj.name
        }
        
    }
    

    
}
