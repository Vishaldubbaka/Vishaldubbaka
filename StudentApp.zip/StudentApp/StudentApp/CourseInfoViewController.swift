//
//  CourseInfoViewController.swift
//  StudentApp
//
//  Created by Dubbaka,Vishal Reddy on 3/24/22.
//

import UIKit

class CourseInfoViewController: UIViewController {
    
    
    @IBOutlet weak var CourseEnrolledOutlet: UILabel!
    
    var coursesArray:[Course] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for course in coursesArray {
            CourseEnrolledOutlet.text = CourseEnrolledOutlet.text! + course.title + "-" + course.sem + "\n"
        // Do any additional setup after loading the view.
    }
    

}
}
